#include <stdio.h>

int main (int argc, char *argv[]) {
	char buffer[512];

	printf("Size = %lu\n", sizeof(buffer));
}


