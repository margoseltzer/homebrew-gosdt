#ifndef DEPENDENCY_H
#define DEPENDENCY_H

#include "key.hpp"

class Dependency {
public:
    // void weight(float const value);
    // float const capacity(void) const;
    // void capacity(float const value);
    // float const pressure(void) const;
    // void pressure(float const value);
private:
    // float _weight = 1.0;
    // float _capacity = 1.0;
    // float _pressure = 1.0;
};

#endif