#ifndef KEY_H
#define KEY_H

#include "bitmask.hpp"

// Hash implementation

class Key {
public:
    // Constructor
    Key(void);
    Key(Bitmask const & indicator, int const feature_index = -1);
    Key(Key const & other);
    Key & operator=(Key const & other);

    Bitmask const & indicator(void) const;
    int const feature_index(void) const;

    bool const operator==(Key const & other) const;
    bool const operator!=(Key const & other) const;
    bool const operator<(Key const & other) const;
    bool const operator>(Key const & other) const;
    bool const operator<=(Key const & other) const;
    bool const operator>=(Key const & other) const;

private:
    Bitmask _indicator;
    int _feature_index;
};

namespace std {
    // Hash implementation
    template <>
    struct hash< Key > {
        std::size_t operator()(Key const & key) const {
            size_t seed = key.feature_index();
            seed ^=  std::hash< Bitmask >()(key.indicator()) + 0x9e3779b9 + (seed<<6) + (seed>>2);
            return seed;
        }
    };
}

#endif