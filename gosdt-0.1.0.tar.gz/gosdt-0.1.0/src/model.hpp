#ifndef MODEL_H
#define MODEL_H

#include <map>
#include <string>

#include "../include/json/json.hpp"

#include "graph.hpp"
#include "key.hpp"
#include "minimization.hpp"
#include "summation.hpp"


using json = nlohmann::json;

class Model {
public:
    Model(void);
    Model(int const feature_index, std::map< int, Model > const & submodels);
    Model(std::map< Bitmask, int > const & distribution);

    std::map< Bitmask, int > const & distribution(void) const;
    int const feature_index(void) const;
    std::map< int, Model > const & submodels(void) const;

    std::map< Bitmask, float > predict(Bitmask const & sample) const;
    std::string serialize(void) const;
    std::string serialize(int const spacing) const;
    json to_json(void) const;
private:
    std::map< Bitmask, int > _distribution;
    int _feature_index = -1;
    std::map< int, Model > _submodels;
};

#endif