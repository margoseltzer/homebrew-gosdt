#include "queue.hpp"

Queue::Queue(void) {
    return;
}

Queue::~Queue(void) {
    return;
}

void Queue::push(Key const & key, float const primary_priority, float const secondary_priority, float const tertiary_priority) {
    if (this -> membership.insert(std::make_pair(key, true))) {
        this -> queue.push(std::tuple< Key, float, float, float >(key, primary_priority, secondary_priority, tertiary_priority));
    }
    return;
}

bool const Queue::empty(void) const {
    return this -> queue.empty();
}

int const Queue::size(void) const {
    return this -> queue.size();
}

bool Queue::pop(std::tuple< Key, float, float, float > & item) {
    if (this -> queue.try_pop(item)) {
        Key key = std::get< 0 >(item);
        this -> membership.erase(key);
        return true;
    } else {
        return false;
    }
}