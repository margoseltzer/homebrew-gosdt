#include "summation.hpp"

Summation::Summation(void) {}

Summation::Summation(float const lowerbound, float const upperbound, float const support, Bitmask const & sensitivity) : Task(lowerbound ,upperbound, support, sensitivity) {}