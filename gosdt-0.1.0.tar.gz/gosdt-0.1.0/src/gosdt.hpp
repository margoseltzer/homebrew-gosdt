#ifndef GOSDT_H
#define GOSDT_H

#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <boost/dynamic_bitset.hpp>

#include "../include/json/json.hpp"

#include "dataset.hpp"
#include "model.hpp"
#include "optimizer.hpp"

using json = nlohmann::json;

class GOSDT {
    std::string configuration;
    public:
        GOSDT(void);
        GOSDT(std::string  configuration);
        ~GOSDT(void);
        std::string get_configuration(void);
        std::string fit(std::string dataset);
        std::string fit(std::string dataset, std::string configuration);
        std::string flow(std::string dataset);
        std::string flow(std::string dataset, std::string configuration);
    private:
        static void work(int const id, Optimizer & optimizer, json configuration, int & return_reference);
};

#endif
