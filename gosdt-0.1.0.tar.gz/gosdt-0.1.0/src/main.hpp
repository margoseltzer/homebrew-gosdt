#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include "../include/json/json.hpp"
#include "../include/csv/csv.h"

#include "gosdt.hpp"

using json = nlohmann::json;

#endif