#ifndef OPTIMIZER_H
#define OPTIMIZER_H

// Invocation Priorities
#define CANCELLATION_PRIORITY 0
#define INFORMATION_PRIORITY 0
#define DELEGATION_PRIORITY 0

#include <chrono>
// #include <mutex>
#include <boost/dynamic_bitset.hpp>
#include "../include/json/json.hpp"

#include <queue>

#include "dataset.hpp"
#include "model.hpp"
#include "graph.hpp"
#include "queue.hpp"

using json = nlohmann::json;

class Optimizer {
    json configuration;
    Dataset dataset;
    Graph graph;
    Queue queue;
public:
    Optimizer(void);
    Optimizer(Dataset const & dataset, json const & configuration);
    ~Optimizer(void);
    bool const complete(void);
    void iterate(int const id = 0);
    float const uncertainty(void);
    std::vector< Model > models(void);

    void diagnose(void);
private:
    // std::mutex mutex;
    std::vector< Model > models(Key const & key, Minimization const & task);
    std::vector< Model > models(Key const & key, Summation const & task);

    void diagnose_minimization(Key const & key);
    void diagnose_summation(Key const & key);

    // Initializers
    Minimization new_minimization(Key const & key, Bitmask const & sensitivity);
    Summation new_summation(Minimization const & supertask, Key const & key);

    float const capacity(Key const & key);
    float const pressure(Key const & key);
    void async_call(Key const & key, float const primary_priority = 0);
    void async_return(tbb::concurrent_unordered_set< Key, GraphIndexHash > callers, Minimization const & task, float const primary_priority = 0);
    void async_return(tbb::concurrent_unordered_set< Key, GraphIndexHash > callers, Summation const & task, float const primary_priority = 0);

    // Graph update kernels
    void minimize(Key const & key);
    void sum(Key const & key);
};

#endif