#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <tuple>
#include <unordered_set>

#include <tbb/concurrent_priority_queue.h>
#include <tbb/concurrent_hash_map.h>
#include "key.hpp"

class PriorityKeyComparator {
public:
    // Note that the tbb::concurrent_priority_queue is implemented to pop the item with the highest priority value
    bool operator()(std::tuple< Key, float, float, float > const & left, std::tuple< Key, float, float, float > const & right) {
        // return left.indicator().count() > right.indicator().count();
        if (std::get< 1 >(left) != std::get< 1 >(right)) {
            return std::get< 1 >(left) < std::get< 1 >(right);
        } else if (std::get< 2 >(left) != std::get< 2 >(right)) {
            return std::get< 2 >(left) < std::get< 2 >(right);
        } else if (std::get< 3 >(left) != std::get< 3 >(right)) {
            return std::get< 3 >(left) < std::get< 3 >(right);
        } else {
            return true;
        }
    }
};

struct MembershipKeyHashCompare {
    static size_t hash(Key const & key) {
        return std::hash< Key >()(key);
    }
    static bool equal(Key const & left, Key const & right) {
        return left == right;
    }
};

class Queue {
    tbb::concurrent_priority_queue< std::tuple< Key, float, float, float >, PriorityKeyComparator > queue;
    // std::queue< Key, std::list< Key > > queue;
    tbb::concurrent_hash_map< Key, bool, MembershipKeyHashCompare > membership;
public:
    Queue(void);
    ~Queue(void);
    void push(Key const & key, float const primary_priority = 0, float const secondary_priority = 0, float const tertiary_priority = 0);
    bool const empty(void) const;
    int const size(void) const;
    bool pop(std::tuple< Key, float, float, float > & item);
};

#endif