void Optimizer::minimize(Key const & key) {
    float const epsilon = std::numeric_limits<float>::epsilon();    

    // From this point, this task cannot be read or written to by other threads
    tbb::concurrent_hash_map<Key, Minimization, GraphVertexHashComparator>::accessor task_accessor;
    if (this -> graph.minimizations.find(task_accessor, key) == false) { throw "Failed Access to Minimization Task (Read)"; }
    Minimization & task = task_accessor -> second;

    // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 

    // Cancels upward flow of information
    if (task.cancelled() || task.resolved()) { return; }

    if (task.explored() == false) {
        task.explore(); // Mark the task as explored once we complete the expansion
        int const m = this -> dataset.width();
        Bitmask const & sensitivity = task.sensitivity();
        // For future work, this can be parallelized
        for (int j = 0; j < m; ++j) {
            if (sensitivity[j] == 0) { continue; }
            std::map< int, Bitmask > partitions = this -> dataset.partition(key.indicator(), j);
            Key subkey(key.indicator(), j);
            if (this -> graph.summations.count(subkey) == 0) {
                tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor subtask_accessor;
                this -> graph.summations.insert(subtask_accessor, std::make_pair(subkey, new_summation(task, subkey))); // Attempt to insert a new task
                Summation const & subtask = subtask_accessor -> second;
                if (subtask.cancelled()) {
                    continue;
                }
            }
            if (this -> graph.forward_index.count(subkey) == 0) {
                this -> graph.forward_index.insert(std::make_pair(subkey, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
            }
            if (this -> graph.backward_index.count(subkey) == 0) {
                this -> graph.backward_index.insert(std::make_pair(subkey, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
            }
            if (this -> graph.alternatives.count(KeyPair(key, subkey)) == 0) {
                this -> graph.alternatives.insert(std::make_pair(KeyPair(key, subkey), Alternative())); // Attempt to insert a new dependency
            }
            // Lock one's own index (this is ok, because children don't lock their parents)
            tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::accessor forward_index_accessor;
            if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Minimization Forward Index (Write)"; }
            forward_index_accessor -> second.insert(subkey);
            // Lock the child's index (this is ok, because children don't lock their parents)
            tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::accessor subtask_backward_index_accessor;
            if (this -> graph.backward_index.find(subtask_backward_index_accessor, subkey) == false) { throw "Failed Access to Minimization Backward Index (Write)"; }
            subtask_backward_index_accessor -> second.insert(key);
        }
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Explored" << std::endl; 

        // Initialize a Similarity Index which is an adjacency matrix using omega as distance

        float const similarity = this -> configuration["similarity"];
        if (similarity > 1.0 / this -> dataset.size()) {
            for (int i = 0; i < m - 1; ++i) {
                if (sensitivity[i] == 0) { continue; }
                std::map< int, Bitmask > source = this -> dataset.partition(key.indicator(), i);
                for (int j = i + 1; j < m; ++j) {
                    if (sensitivity[j] == 0) { continue; }
                    std::map< int, Bitmask > destination = this -> dataset.partition(key.indicator(), j);
                    float distance = std::min(((source[0] & destination[1]) | (source[1] & destination[0])).count(), ((source[0] & destination[0]) | (source[1] & destination[1])).count()) / this -> dataset.size();
                    if (0 < distance && distance < similarity) {
                        task.similarity_index.emplace_back(i, j, distance);
                    }
                }
            }
        }
    } // From this point, the task has completed the expansion

    // From this point this index cannot be read or written to by other threads
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor backward_index_accessor;
    if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Minimization Forward Index (Read)"; }
    if (this -> graph.backward_index.find(backward_index_accessor, key) == false) { throw "Failed Access to Minimization Backward Index (Read)"; }
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & backward_index = backward_index_accessor -> second;
    // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") connected to " << forward_index.size() << " subtasks and " << backward_index.size() << " supertasks" << std::endl;    

    float convergence = (float)(this -> configuration["similarity"]) / this -> dataset.size();
    while (convergence > 0) {
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Similar Support Kernel" << std::endl;   
        convergence = 0;
        // Some Similar Support Magic
        for (auto iterator = task.similarity_index.begin(); iterator != task.similarity_index.end(); ++iterator) {
            std::tuple< int, int, float > relation = * iterator;
            int i = std::get< 0 >(relation);
            int j = std::get< 1 >(relation);
            float distance = std::get< 2 >(relation);
            // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Similar Support Source" << std::endl;    
            Key source_key(key.indicator(), i);
            tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::accessor source_accessor;
            if (this -> graph.summations.find(source_accessor, source_key) == false) { break; }
            Summation & source = source_accessor -> second;

            Key destination_key(key.indicator(), j);
            tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::accessor destination_accessor;
            if (this -> graph.summations.find(destination_accessor, destination_key) == false) { break; }
            Summation & destination = destination_accessor -> second;

            std::priority_queue< float > bounds;
            bounds.push(source.lowerbound());
            bounds.push(source.upperbound());
            bounds.push(destination.lowerbound());
            bounds.push(destination.upperbound());

            bounds.pop();
            float mutual_upperbound = bounds.top() + distance;
            bounds.pop();
            float mutual_lowerbound = bounds.top() - distance;

            // std::cout << "Similar Support Source (" << source.lowerbound() << ", " << source.upperbound() << ")" << std::endl;
            // std::cout << "Similar Support Destination (" << destination.upperbound() << ", " << destination.upperbound() << ")" << std::endl;
            // std::cout << "Similar Support Distance = " << distance << std::endl;
            // std::cout << "Similar Support Bound (" << mutual_lowerbound << ", " << mutual_upperbound << ")" << std::endl;

            if (mutual_lowerbound > source.lowerbound()) {
                source.inform(mutual_lowerbound, source.upperbound());
                convergence += mutual_lowerbound - source.lowerbound();
            }
            if (mutual_upperbound < source.upperbound()) {
                source.inform(source.lowerbound(), mutual_upperbound);
                convergence += source.upperbound() - mutual_upperbound;
            }
            if (mutual_lowerbound > destination.lowerbound()) {
                destination.inform(mutual_lowerbound, destination.upperbound());
                convergence += mutual_lowerbound - destination.lowerbound();
            }
            if (mutual_upperbound < destination.upperbound()) {
                destination.inform(destination.lowerbound(), mutual_upperbound);
                convergence += destination.upperbound() - mutual_upperbound;
            }
        }
    }

    float const initial_lowerbound = task.lowerbound();
    float const initial_upperbound = task.upperbound();
    float lowerbound = initial_upperbound;
    float strong_upperbound = initial_upperbound;
    // For future work, this can be parallelized
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key const & subkey = * iterator;
        // From this point, the subtask is read-only
        tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor subtask_accessor;
        if (this -> graph.summations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Minimization Subtask (Reduction)"; }
        Summation const & subtask = subtask_accessor -> second;

        if (subtask.cancelled() == false) {
            lowerbound = std::min(subtask.lowerbound(), lowerbound);
        }
        strong_upperbound = std::min(subtask.upperbound(), strong_upperbound);
    }

    // Update the task with the new bounds
    float upperbound = strong_upperbound;
    // std::cout << "Minimization::inform(" << lowerbound << ", " << upperbound << ")" << std::endl; 
    task.inform(lowerbound, upperbound);

    if (task.lowerbound() > task.support()) {
        // Test the whether the subtree lowerbound exceeds threshold for an optimal solution (Theorem 5)
        task.cancel();
        async_return(backward_index, task, CANCELLATION_PRIORITY); // Inform parents of termination
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Cancelled" << std::endl;    
        return;
    }

    // While the strong upperbound represents the bound of the best global optima so far
    // The weak upperbound represents the bound of all global optima, which tends to lag behind by a little bit
    // The strong upperbound is used to represent how promising the task is, but the weak upperbound is used to decide termination
    float weak_upperbound = strong_upperbound;
    // For future work, this can be parallelized
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key const & subkey = * iterator;
        // From this point, the subtask is read-only
        tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor subtask_accessor;
        if (this -> graph.summations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Minimization Subtask (Reduction)"; }
        Summation const & subtask = subtask_accessor -> second;
        if (subtask.lowerbound() <= strong_upperbound) {
            weak_upperbound = std::max(subtask.upperbound(), weak_upperbound);
        }
    }

    if ( weak_upperbound - lowerbound < epsilon ) { // Task Complete
        task.resolve();
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Resolved" << std::endl;    
    }
    if (lowerbound != initial_lowerbound || upperbound != initial_upperbound) {
        async_return(backward_index, task, INFORMATION_PRIORITY); // Inform parents of incremental updates
    }

    // From this point, we know that further exploration of subtasks needs to be done
    if (task.delegated() == false && task.resolved() == false) {
        task.delegate();
        // For future work, this can be parallelized
        for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
            Key const & subkey = * iterator;
            tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::accessor subtask_accessor;
            if (this -> graph.summations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Minimization Subtask (Delegation)"; }
            Summation & subtask = subtask_accessor -> second;
            if (subtask.lowerbound() <= strong_upperbound && subtask.resolved() == false) {
                subtask_accessor.release();
                async_call(subkey, DELEGATION_PRIORITY);
                // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") delegated to Summation(" << subkey.indicator().to_string() << ", " << subkey.feature_index() << ")" << std::endl;    
            }
        }
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Delegated" << std::endl;    
    }
    return;
}