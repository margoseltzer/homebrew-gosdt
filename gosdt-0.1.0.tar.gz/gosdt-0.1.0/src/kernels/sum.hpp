void Optimizer::sum(Key const & key) {

    // From this point, this task cannot be read or written to by other threads
    tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::accessor task_accessor;
    if (this -> graph.summations.find(task_accessor, key) == false) { throw "Failed Access to Summation Task (Read)"; }
    Summation & task = task_accessor -> second;

    // std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 

    // Cancels upward flow of information
    if (task.cancelled() || task.resolved()) { return; }

    if (task.explored() == false) {
        task.explore(); // Mark the task as explored once we complete the one-step look-ahead
        std::map< int, Bitmask > partitions = this -> dataset.partition(key.indicator(), key.feature_index());
        // For future work, this can be parallelized
        for (auto iterator = partitions.begin(); iterator != partitions.end(); ++iterator) {
            int const feature_value = iterator -> first;
            Key subkey(iterator -> second, -1);
            if (subkey.indicator().count() == key.indicator().count() || subkey.indicator().count() == 0) {
                // Detected that this feature does not partition the dataset in any way
                // proving that this summation only inccurs unnecessary regularization cost
                task.cancel();
                break;
            }
            if (this -> graph.minimizations.count(subkey) == 0) {
                this -> graph.minimizations.insert(std::make_pair(subkey, new_minimization(subkey, task.sensitivity()))); // Attempt to insert a new task
            }
            if (this -> graph.forward_index.count(subkey) == 0) { 
                this -> graph.forward_index.insert(std::make_pair(subkey, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
            }
            if (this -> graph.backward_index.count(subkey) == 0) { 
                this -> graph.backward_index.insert(std::make_pair(subkey, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
            }
            if (this -> graph.summands.count(KeyPair(key, subkey)) == 0) {
                this -> graph.summands.insert(std::make_pair(KeyPair(key, subkey), Summand(feature_value))); // Attempt to insert a new dependency
            }
            // Lock one's own index (this is ok, because children don't lock their parents)
            tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::accessor forward_index_accessor;
            if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Summation Forward Index (Write)"; }
            forward_index_accessor -> second.insert(subkey);
            // Lock the child's index (this is ok, because children don't lock their parents)
            tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::accessor subtask_backward_index_accessor;
            if (this -> graph.backward_index.find(subtask_backward_index_accessor, subkey) == false) { throw "Failed Access to Summation Forward Index (Write)"; }
            subtask_backward_index_accessor -> second.insert(key);
        }
    } // From this point, the task has completed a one-step look-ahead
        
    // From this point this index cannot be read or written to by other threads
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor backward_index_accessor;
    if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Summation Forward Index (Read)"; }
    if (this -> graph.backward_index.find(backward_index_accessor, key) == false) { throw "Failed Access to Summation Backward Index (Read)"; }
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & backward_index = backward_index_accessor -> second;
    // std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ") connected to " << forward_index.size() << " subtasks and " << backward_index.size() << " supertasks" << std::endl;    

    // Perform a look-ahead if it has not occurred yet
    float const initial_lowerbound = task.lowerbound();
    float const initial_upperbound = task.upperbound();
    float lowerbound = 0;
    float upperbound = 0;
    // For future work, this can be parallelized
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key const & subkey = * iterator;
        // From this point, other threads can only read this subtask            
        tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor subtask_accessor;
        if (this -> graph.minimizations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Summation Subtask (Reduction)"; }
        Minimization const & subtask = subtask_accessor -> second;
        lowerbound += subtask.lowerbound();
        upperbound += subtask.upperbound();
    }

    lowerbound = std::max(initial_lowerbound, lowerbound);
    upperbound = std::min(initial_upperbound, upperbound);

    if (lowerbound > upperbound) {
        // Test the whether the subtree lowerbound exceeds threshold for an optimal solution (Theorem 5)
        task.cancel();
        async_return(backward_index, task, CANCELLATION_PRIORITY); // Inform parents of termination
        // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << ") Cancelled" << std::endl;    
        return;
    }

    // Update the task with the new bounds
    // std::cout << "Summation::inform(" << lowerbound << ", " << upperbound << ")" << std::endl; 
    task.inform(lowerbound, upperbound);


   if (task.uncertainty() <= 0) {
        // std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ") Resolved" << std::endl;    
        task.resolve();
    }

    if (lowerbound != initial_lowerbound || upperbound != initial_upperbound) {
        async_return(backward_index, task, INFORMATION_PRIORITY); // Inform parents of incremental updates
    }

    // From this point, we know that further exploration of subtasks needs to be done
    if (task.delegated() == false && task.resolved() == false) {
        task.delegate();
        // For future work, this can be parallelized
        for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
            Key const & subkey = *iterator;
            // From this point, other threads can only read this subtask            
            tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::accessor subtask_accessor;
            if (this -> graph.minimizations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Summation Subtask (Delegation)"; }
            Minimization & subtask = subtask_accessor -> second;        
            if (subtask.resolved() == false) {
                subtask_accessor.release();
                async_call(subkey, DELEGATION_PRIORITY);
            }
        }
        // std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ") Delegated" << std::endl;    
    }
    return;
}