
Minimization Optimizer::new_minimization(Key const & key, Bitmask const & sensitivity) {
    float const epsilon = std::numeric_limits<float>::epsilon();    
    std::tuple< float, float, float > const & impurity = this -> dataset.impurity(key.indicator());
    float const regularization = this -> configuration["regularization"];
    float const size = this -> dataset.size();
    float const lowerbound = std::get<0>(impurity) / size + regularization;
    float const upperbound = std::get<1>(impurity) / size + regularization;
    float const support = std::get<2>(impurity) / size;
    float const base_objective = upperbound;
    Minimization task = Minimization(lowerbound, upperbound, support, base_objective, sensitivity);
    if (task.lowerbound() > task.support()) {
        // Test the whether the subtree lowerbound exceeds threshold for an optimal solution (Theorem 5)
        task.cancel();
    } else if (
        ( task.uncertainty() <= regularization - epsilon ) // Incremental Accuracy Lowerbound Bound Failed
        || ( 0.5 * task.support() <= regularization - epsilon ) // Support Lowerbound Failed
        || ( key.indicator().count() <= 1 ) // Equivalent Group cannot be split further
        || ( task.sensitivity().count() <= 0 ) // Equivalent Group cannot be split further
    ) {
        task.resolve();
    }
    return task;
}

Summation Optimizer::new_summation(Minimization const & supertask, Key const & key) {
    boost::dynamic_bitset<> selector;
    selector.resize(this -> dataset.width(), 1);
    selector[key.feature_index()] = 0;
    Bitmask const sensitivity = supertask.sensitivity() & selector;
    Summation task = Summation(supertask.lowerbound(), supertask.upperbound(), supertask.support(), sensitivity);
    std::map< int, Bitmask > partitions = this -> dataset.partition(key.indicator(), key.feature_index());
    for (auto iterator = partitions.begin(); iterator != partitions.end(); ++iterator) {
        Key subkey(iterator -> second, -1);
        if (subkey.indicator().count() == key.indicator().count() || subkey.indicator().count() == 0) {
            // Detected that this feature does not partition the dataset in any way
            // proving that this summation only inccurs unnecessary regularization cost
            task.cancel();
            break;
        }
    }
    return task;
}

void Optimizer::async_call(Key const & callee, float const primary_priority) {
    float secondary_priority = 0; // capacity(callee);
    float tertiary_priority = 0;
    this -> queue.push(callee, primary_priority, secondary_priority, tertiary_priority);
}

void Optimizer::async_return(tbb::concurrent_unordered_set< Key, GraphIndexHash > callers, Minimization const & task, float const primary_priority) {
    // For future work, this can be parallelized
    for (auto iterator = callers.begin(); iterator != callers.end(); ++ iterator) {
        Key const & superkey = * iterator;
        float const secondary_priority = 0; // pressure(superkey);
        float const tertiary_priority = 0;
        this -> queue.push(superkey, primary_priority, secondary_priority, tertiary_priority);
    }
}

void Optimizer::async_return(tbb::concurrent_unordered_set< Key, GraphIndexHash > callers, Summation const & task, float const primary_priority) {
    // For future work, this can be parallelized
    for (auto iterator = callers.begin(); iterator != callers.end(); ++ iterator) {
        Key const & superkey = * iterator;
        float const secondary_priority = 0; // pressure(superkey);
        float const tertiary_priority = 0;
        this -> queue.push(superkey, primary_priority, secondary_priority, tertiary_priority);
    }
}