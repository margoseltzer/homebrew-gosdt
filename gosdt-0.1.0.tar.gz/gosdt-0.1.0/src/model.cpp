#include "model.hpp"

Model::Model(void) {}

Model::Model(int const feature_index, std::map< int, Model > const & submodels) : _feature_index(feature_index), _submodels(submodels) {}

Model::Model(std::map< Bitmask, int > const & distribution) : _distribution(distribution) {}


std::map< Bitmask, int > const & Model::distribution(void) const {
    return this -> _distribution;
}

int const Model::feature_index(void) const {
    return this -> _feature_index;
}

std::map< int, Model > const & Model::submodels(void) const {
    return this -> _submodels;
}


std::map< Bitmask, float > Model::predict(Bitmask const & sample) const {
    // Currently a stub, need to implement
    std::map< Bitmask, float > prediction;
    return prediction;
}

std::string Model::serialize(void) const {
    return to_json().dump();
}

std::string Model::serialize(int const spacing) const {
    return to_json().dump(spacing);
}

json Model::to_json(void) const {
    json node = json::object();
    if (this -> _feature_index == -1) {
        node["leaf"] = true;
        json subnode = json::object();
        std::map< Bitmask, int > const & dist = distribution();
        for (auto iterator = dist.begin(); iterator != dist.end(); ++iterator) {
            subnode[(iterator -> first).to_string()] = iterator -> second;
        }
        node["distribution"] = subnode;
    } else {
        node["leaf"] = false;
        node["feature_index"] = this -> _feature_index;
        json subnode = json::object();
        std::map< int, Model > const & submodels = this -> _submodels;
        for (auto iterator = submodels.begin(); iterator != submodels.end(); ++iterator) {
            subnode[std::to_string(iterator -> first)] = (iterator -> second).to_json();
        }
        node["branches"] = subnode;
    }
    return node;
}