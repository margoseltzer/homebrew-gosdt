#ifndef ALTERNATIVE_H
#define ALTERNATIVE_H

#include "dependency.hpp"

class Alternative : public Dependency {
public:
    Alternative(void);
private:
};

#endif
