#include "graph.hpp"

Graph::Graph(void) {
    return;
}

Graph::~Graph(void) {
    return;
}