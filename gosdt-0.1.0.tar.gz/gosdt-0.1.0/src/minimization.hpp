#ifndef Minimization_H
#define Minimization_H

#include "task.hpp"

class Minimization : public Task {
public:
    Minimization(void);
    Minimization(float const lowerbound, float const upperbound, float const support, float base_objective, Bitmask const & sensitivity);
    float const base_objective(void) const;
private:
    float _base_objective;
};

#endif
