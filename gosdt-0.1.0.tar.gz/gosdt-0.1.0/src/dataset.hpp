#ifndef DATASET_H
#define DATASET_H

#define CL_SILENCE_DEPRECATION
#define __CL_ENABLE_EXCEPTIONS

#include <iostream>
#include <map>
#include <vector>
#include <tuple>
#include <assert.h>
#include <boost/dynamic_bitset.hpp>

#ifdef __APPLE__
#include "../include/opencl/cl.hpp"
#else
#include "../include/opencl/cl.hpp"
#endif

#include "../include/json/json.hpp"

#include "bitmask.hpp"

using json = nlohmann::json;

class Dataset {
public:
    Dataset(void);
    Dataset(std::string const & source);
    Dataset(std::istream & source);
    Dataset(json source);
    ~Dataset(void);

    // Computes the lowerbound and upperbound of a subset
    std::tuple< float, float, float > impurity(void) const;
    std::tuple< float, float, float > impurity(Bitmask const & indicator) const;

    // Computes the subsets of a set as paritioned by a feature
    std::map< int, Bitmask > partition(int const feature_index) const;
    std::map< int, Bitmask > partition(Bitmask const & indicator, int const feature_index) const;

    std::map< Bitmask, int > distribution(void) const;
    std::map< Bitmask, int > distribution(Bitmask const & indicator) const;

    int const size(void) const;
    int const height(void) const;
    int const width(void) const;
    int const depth(void) const;

    // void push(boost::dynamic_bitset<> features, boost::dynamic_bitset<> labels);
private:
    std::vector< std::tuple< Bitmask, int > > labels;
    std::vector< std::tuple< Bitmask, std::vector< int > > > rows;
    std::vector< Bitmask > columns;
    std::tuple< int, int, int > shape;
    int _size;

    void initialize(json source);
    void initialize_kernel(void);
    std::tuple< float, float, float > _impurity(Bitmask const & indicator) const;
    std::map< int, Bitmask > _partition(Bitmask const & indicator, int const feature_index) const;
};

#endif
