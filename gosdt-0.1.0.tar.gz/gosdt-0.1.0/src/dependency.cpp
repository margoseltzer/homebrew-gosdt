#include "dependency.hpp"

// void Dependency::weight(float const value) {
//     this -> _weight = value;
//     return;
// }

// float const Dependency::capacity(void) const {
//     return (this -> _capacity) * (this -> _weight);
// }

// void Dependency::capacity(float const value) {
//     this -> _capacity = value;
//     return;
// }

// float const Dependency::pressure(void) const {
//     return (this -> _pressure) * (this -> _weight);
// }

// void Dependency::pressure(float const value) {
//     this -> _pressure = value;
//     return;
// }
