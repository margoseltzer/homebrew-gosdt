#ifndef SUMMAND_H
#define SUMMAND_H

#include "dependency.hpp"

class Summand : public Dependency {
public:
    Summand(void);
    Summand(int const feature_value);
    int const feature_value(void) const;
private:
    int _feature_value;
};

#endif


