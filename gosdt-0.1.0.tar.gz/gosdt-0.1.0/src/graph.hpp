#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <utility>
#include <unordered_map>
#include <unordered_set>

#include <tbb/concurrent_hash_map.h>
#include <tbb/concurrent_unordered_map.h>
#include <tbb/concurrent_unordered_set.h>
#include "key.hpp"
#include "key_pair.hpp"
#include "minimization.hpp"
#include "summation.hpp"
#include "summand.hpp"
#include "alternative.hpp"

// Additional Hash Implementation for tbb::concurrent_hash_table
// These delegate to the already implemented hash functions and equality operators
struct GraphIndexHash {
    std::size_t operator()(Key const & key) const {
        return std::hash< Key >()(key);
    }
};

struct GraphVertexHashComparator {
    static size_t hash(Key const & key) {
        return std::hash< Key >()(key);
    }
    static bool equal(Key const & left, Key const & right) {
        return left == right;
    }
};

struct GraphEdgeHashComparator {
    static size_t hash(KeyPair const & pair) {
        return pair.hash();
        // return std::hash< KeyPair >()(pair);
    }
    static bool equal(KeyPair const & left, KeyPair const & right) {
        return left == right;
    }
};
 

class Graph {
public:
    // Working Set for Wait-Free Mutual Exclusion
    tbb::concurrent_hash_map< Key, bool, GraphVertexHashComparator > working_set;

    // Vertices
    tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator > minimizations;
    tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator > summations;

    // Edges
    tbb::concurrent_hash_map< KeyPair, Alternative, GraphEdgeHashComparator > alternatives;
    tbb::concurrent_hash_map< KeyPair, Summand, GraphEdgeHashComparator > summands;

    // (forward and backward indices)
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator > forward_index;
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator > backward_index;

    Graph(void);
    ~Graph(void);
};

#endif
