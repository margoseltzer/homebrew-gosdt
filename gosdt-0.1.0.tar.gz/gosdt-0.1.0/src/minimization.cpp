#include "minimization.hpp"

Minimization::Minimization(void) {}

Minimization::Minimization(float const lowerbound, float const upperbound, float const support, float const base_objective, Bitmask const & sensitivity) :
    Task(lowerbound ,upperbound, support, sensitivity), _base_objective(base_objective) {
}

float const Minimization::base_objective(void) const {
    return this -> _base_objective;
}