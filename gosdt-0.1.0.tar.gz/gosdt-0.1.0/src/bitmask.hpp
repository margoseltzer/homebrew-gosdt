#ifndef BITMASK_H
#define BITMASK_H

#include <unordered_map>
#include <vector>
#include <boost/dynamic_bitset.hpp>

class Bitmask {
public:
    // Convenience Constructor
    static Bitmask zeros(int const size);
    static Bitmask ones(int const size);

    Bitmask(void);
    Bitmask(boost::dynamic_bitset<> const & reference);

    boost::dynamic_bitset<> const & value(void) const;
    int const operator[](int index) const;
    int const count(void) const;
    int const size(void) const;
    size_t const hash(void) const;
    std::vector<int> const & encoding(void) const;

    bool const operator==(Bitmask const & other) const;
    bool const operator!=(Bitmask const & other) const;
    bool const operator<=(Bitmask const & other) const;
    bool const operator>=(Bitmask const & other) const;
    bool const operator<(Bitmask const & other) const;
    bool const operator>(Bitmask const & other) const;

    Bitmask const operator&(Bitmask const & other) const;
    Bitmask const operator^(Bitmask const & other) const;
    Bitmask const operator|(Bitmask const & other) const;
    Bitmask const operator-(Bitmask const & other) const;
    Bitmask const operator~(void) const;

    std::string const to_string(void) const;

private:
    boost::dynamic_bitset<> reference;
    size_t hash_code;
    std::vector< int > run_length_code;
    static Bitmask fill(int const fill, int const size);
};

// Hash implementation
namespace std {
    template <>
    struct hash< Bitmask > {
        std::size_t operator()(Bitmask const & bitmask) const {
            return bitmask.hash();
        }
    };
}

#endif
