#include "gosdt.hpp"

#define _DEBUG true
#define THROTTLE false

GOSDT::GOSDT(void) {
    json configuration = json::object();
    configuration["regularization"] = 0.1;
    configuration["uncertainty_tolerance"] = 0.0;
    configuration["workers"] = 1;
    configuration["time_limit"] = 0;
    configuration["wait_free"] = true;
    configuration["acceleration"] = true;
    configuration["similarity"] = 0;
    configuration["verbose"] = true;
    this -> configuration = configuration.dump();
    return;
}

GOSDT::GOSDT(std::string configuration) : configuration(configuration) {}

GOSDT::~GOSDT(void) {
    return;
}

std::string GOSDT::get_configuration(void) {
    return this -> configuration;
}

void GOSDT::work(int const id, Optimizer & optimizer, json configuration, int & return_reference) {
    auto start = std::chrono::high_resolution_clock::now();
    float const time_limit = configuration["time_limit"];
    int iterations = 0;

    while (optimizer.complete() == false) {
        auto now = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(now - start);
        if (time_limit > 0 && duration.count() / 1000000.0 > time_limit) { break; }
        if (THROTTLE) { std::this_thread::sleep_for(std::chrono::milliseconds(200)); }
        try{
            optimizer.iterate(id);
            ++iterations;
        } catch( const char * exception ) {
            std::cout << exception << std::endl;
            optimizer.diagnose();
            break;
        }
    }
    return_reference = iterations;
}

std::string GOSDT::fit(std::string data_source) {
    return fit(data_source, this -> configuration);
}

std::string GOSDT::fit(std::string data_source, std::string configuration_source) {

    std::string result;
    Dataset dataset(data_source);
    json configuration = json::parse(configuration_source);
    Optimizer optimizer(dataset, configuration);

    auto start = std::chrono::high_resolution_clock::now();

    int const pool_size = std::max(1, (int)(configuration["workers"]));
    std::vector< std::thread > workers;
    std::vector< int > results(pool_size);

    for (int i = 0; i < pool_size; ++i) {
        workers.emplace_back(work, i, std::ref(optimizer), configuration, std::ref(results[i]));
    }
    for (auto iterator = workers.begin(); iterator != workers.end(); ++iterator) {
        std::thread & worker = * iterator;
        worker.join();
    }
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start); 
    std::cout << "Training Duration: " << duration.count() / 1000000.0 << " seconds" << std::endl;

    int iterations = 0;
    for (auto iterator = results.begin(); iterator != results.end(); ++iterator) {
        iterations += * iterator;
    }
    std::cout << "Training Iterations: " << iterations << " iterations" << std::endl;


    std::cout << "Model Uncertainty: " << optimizer.uncertainty() << std::endl;

    try{

        std::vector< Model > const & models = optimizer.models();
        std::cout << "Models Generated: " << models.size() << std::endl;
        json output = json::array();
        for (auto iterator = models.begin(); iterator != models.end(); ++iterator) {
            Model model = * iterator;
            output.push_back(model.to_json());
        }
        result = output.dump(4);
        return result;
    } catch(const char * exception) {
        std::cout << exception << std::endl;
        result = std::string(exception);
        return result;
    }
}