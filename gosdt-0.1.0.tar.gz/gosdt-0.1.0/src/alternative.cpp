#include "alternative.hpp"

Alternative::Alternative(void) {}