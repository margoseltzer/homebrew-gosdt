#include "optimizer.hpp"

#include "kernels/utility.hpp"
#include "kernels/minimize.hpp"
#include "kernels/sum.hpp"


Optimizer::Optimizer(void) {
    return;
}

Optimizer::Optimizer(Dataset const & dataset, json const & configuration) : configuration(configuration), dataset(dataset) {
    // Seed the optimizer with a root problem
    Key key(Bitmask::ones(dataset.height()));
    Bitmask sensitivity = Bitmask::ones(this -> dataset.width());
    this -> queue.push(key);
    this -> graph.minimizations.insert(std::make_pair(key, new_minimization(key, sensitivity))); // Attempt to insert a new task
    this -> graph.forward_index.insert(std::make_pair(key, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
    this -> graph.backward_index.insert(std::make_pair(key, tbb::concurrent_unordered_set< Key, GraphIndexHash >())); // Initializes a new index
    return;
}

Optimizer::~Optimizer(void) {
    return;
}

float const Optimizer::uncertainty(void) {
    Key key(Bitmask::ones(this -> dataset.height()));
    tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor task_accessor;
    if (this -> graph.minimizations.find(task_accessor, key)) {
        Minimization const & task = task_accessor -> second;
        if (this -> configuration["verbose"]) {
            std::cout << "Global Progress = [" << task.lowerbound() << ", " << task.upperbound() << "]" << std::endl;
        }
        return task.uncertainty();
    } else {
        return 1.0;
    }
}

bool const Optimizer::complete(void) {
    Key key(Bitmask::ones(this -> dataset.height()));
    tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor task_accessor;
    if (this -> graph.minimizations.find(task_accessor, key)) {
        Minimization const & task = task_accessor -> second;
        if (this -> configuration["verbose"]) {
            std::cout << "Global Progress = [" << task.lowerbound() << ", " << task.upperbound() << "]" << std::endl;
        }
        return task.resolved();
    } else {
        return false;
    }
}

void Optimizer::iterate(int const id) {
    std::tuple< Key, float, float, float > item;
    if (this -> queue.pop(item)) {
        Key key = std::get< 0 >(item);
        // std::cout << "Task(" << key.indicator().to_string() << ", " << key.feature_index() << "), Priorities = (" << std::get< 1 >(item) << ", " << std::get< 2 >(item) << ", " << std::get< 3 >(item) << ") " << std::endl; 
        // std::cout << "Queue Size = " << this -> queue.size() << ", Graph Size = " << this -> graph.minimizations.size() + this -> graph.summations.size() << std::endl; 

        if (this -> configuration["wait_free"] == true) {
            // Acquire main task lock
            bool contended = false;
            if (this -> graph.working_set.insert(std::make_pair(key, true))) {
                std::vector< Key > acquired;
                // Acquire subtask lock if any
                tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
                if (this -> graph.forward_index.find(forward_index_accessor, key)) {
                    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
                    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
                        Key const & subkey = * iterator;
                        if (this -> graph.working_set.insert(std::make_pair(subkey, true))) {
                            acquired.push_back(subkey);
                        } else {
                            contended = true;
                            break;
                        }
                    }
                    forward_index_accessor.release();
                }

                // Execute task if no contention was detected
                if (contended == false) {
                    if (key.feature_index() == -1) { minimize(key); } else { sum(key); }
                }

                // Release subtask lock if any
                for (auto iterator = acquired.begin(); iterator != acquired.end(); ++iterator) {
                    Key const & subkey = * iterator;
                    this -> graph.working_set.erase(subkey);
                }
                // Release main task lock
                this -> graph.working_set.erase(key);
            } else {
                contended = true;
            }
            if (contended) {
                this -> queue.push(key, std::get< 1 >(item), std::get< 2 >(item), std::get< 3 >(item)); // Defer this task
            }
        } else {
            if (key.feature_index() == -1) {
                minimize(key);
            } else {
                sum(key);
            }            
        }
        
    }
    return;
}

void Optimizer::diagnose(void) {
    Key key(Bitmask::ones(this -> dataset.height()));
    diagnose_minimization(key);
}

void Optimizer::diagnose_minimization(Key const & key) {
    tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor task_accessor;
    this -> graph.minimizations.find(task_accessor, key);
    Minimization const & task = task_accessor -> second;
    if (task.resolved()) {
        return;
    }

    std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 

    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
    this -> graph.forward_index.find(forward_index_accessor, key);
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
    int reasons = 0;
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key subkey = * iterator;
        tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor subtask_accessor;
        this -> graph.summations.find(subtask_accessor, key);
        Summation const & subtask = subtask_accessor -> second;
        if (subtask.resolved() == false) {
            ++reasons;
            if (subtask.lowerbound() == task.lowerbound()) {
                std::cout << "Minimization(" << key.indicator().to_string() << ")'s lowerbound depends on Summation(" << subkey.indicator().to_string() << ", " << subkey.feature_index() << ")" << std::endl;
            }
            if (subtask.upperbound() == task.upperbound()) {
                std::cout << "Minimization(" << key.indicator().to_string() << ")'s upperbound depends on Summation(" << subkey.indicator().to_string() << ", " << subkey.feature_index() << ")" << std::endl;
            }
            if (subtask.lowerbound() == task.lowerbound() || subtask.upperbound() == task.upperbound()) {
                diagnose_summation(subkey);
            }
        }
    }
    if (reasons == 0) {
        if (forward_index.size() == 0) {
            std::cout << "Minimization(" << key.indicator().to_string() << ") is missing a downward call." << std::endl;
        } else {
            std::cout << "Minimization(" << key.indicator().to_string() << ") is missing an upward call." << std::endl;
        }
    }
}

void Optimizer::diagnose_summation(Key const & key) {
    tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor task_accessor;
    this -> graph.summations.find(task_accessor, key);
    Summation const & task = task_accessor -> second;

    if (task.resolved()) {
        return;
    }

    std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 

    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
    this -> graph.forward_index.find(forward_index_accessor, key);
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
    int reasons = 0;
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key subkey = * iterator;
        tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor subtask_accessor;
        this -> graph.minimizations.find(subtask_accessor, key);
        Minimization const & subtask = subtask_accessor -> second;
        if (subtask.resolved() == false) {
            ++reasons;
            std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ")'s bounds depend on Minimization(" << subkey.indicator().to_string() << ")" << std::endl;
            diagnose_minimization(subkey);
        }
    }
    if (reasons == 0) {
        if (forward_index.size() == 0) {
            std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ") is missing a downward call." << std::endl;
        } else {
            std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << ") is missing an upward call." << std::endl;
        }
    }
}

std::vector< Model > Optimizer::models(void) {
    Key key(Bitmask::ones(this -> dataset.height()));
    tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor task_accessor;
    this -> graph.minimizations.find(task_accessor, key);
    Minimization const & task = task_accessor -> second;
    std::vector< Model > results = models(key, task);
    // std::vector< Model > results;
    return results;
}

std::vector< Model > Optimizer::models(Key const & key, Minimization const & task) {
    // std::cout << "Minimization(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 
    
    if (task.cancelled() == true) {
        std::vector< Model > results;
        return results;
    } else {
        std::vector< Model > results;

        if (task.base_objective() <= task.upperbound()) {
            // Optimal models include a stump
            Model model(this -> dataset.distribution(key.indicator()));
            results.push_back(model);
        }

        tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
        if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Minimization Forward Index (Extraction)"; }

        tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
        for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
            Key const & subkey = * iterator;
            tbb::concurrent_hash_map< Key, Summation, GraphVertexHashComparator >::const_accessor subtask_accessor;
            if (this -> graph.summations.find(subtask_accessor, subkey) == false) { throw "Failed Access to Minimization Subtask (Extraction)"; }
            Summation const & subtask = subtask_accessor -> second;
            if (subtask.upperbound() <= task.upperbound() && subtask.cancelled() == false) {
                // transfer the models from the qualifying summation into overall list of models
                std::vector< Model > const & submodels = models(subkey, subtask);
                for (auto iterator = submodels.begin(); iterator != submodels.end(); ++iterator) {
                    Model submodel = * iterator;
                    results.push_back(submodel);
                }
            }
        }
        return results;
    }
}

std::vector< Model > Optimizer::models(Key const & key, Summation const & task) {
    // std::cout << "Summation(" << key.indicator().to_string() << ", " << key.feature_index() << "), Bounds = " << "[" << task.lowerbound() << ", " << task.upperbound() << "]" << " State(E|D|R|C) = " << task.explored() << task.delegated() << task.resolved() << task.cancelled() << std::endl; 
    
    tbb::concurrent_hash_map< Key, tbb::concurrent_unordered_set< Key, GraphIndexHash >, GraphVertexHashComparator >::const_accessor forward_index_accessor;
    if (this -> graph.forward_index.find(forward_index_accessor, key) == false) { throw "Failed Access to Summation Forward Index (Extraction)"; }    
    tbb::concurrent_unordered_set< Key, GraphIndexHash > const & forward_index = forward_index_accessor -> second;
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key const & subkey = * iterator;
        tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor subtask_accessor;
        if (this -> graph.minimizations.find(subtask_accessor, subkey) ==  false) { throw "Failed Access to Summation Subtask (Extraction)"; }
        Minimization const & subtask = subtask_accessor -> second;
        if (subtask.cancelled()) {
            std::vector< Model > results;
            return results;
        }
    }

    std::vector< int > values;
    std::vector< std::vector< Model > > model_space;
    // Create a model space such that each subtask is a dimension
    // and the models from that subtask are the values of that dimension
    for (auto iterator = forward_index.begin(); iterator != forward_index.end(); ++iterator) {
        Key const & subkey = * iterator;
        tbb::concurrent_hash_map< Key, Minimization, GraphVertexHashComparator >::const_accessor subtask_accessor;
        tbb::concurrent_hash_map< KeyPair, Summand, GraphEdgeHashComparator >::const_accessor dependency_accessor;
        if (this -> graph.minimizations.find(subtask_accessor, subkey) ==  false) { throw "Failed Access to Summation Subtask (Extraction)"; }
        if (this -> graph.summands.find(dependency_accessor, KeyPair(key, subkey)) ==  false) { throw "Failed Access to Summation Dependency (Extraction)"; }
        Minimization const & subtask = subtask_accessor -> second;
        Summand const & dependency = dependency_accessor -> second;
        model_space.push_back(models(subkey, subtask));
        values.push_back(dependency.feature_value());
    }

    for (int k = 0; k < model_space.size(); ++k) {
        std::vector< Model > submodels = model_space[k];
        if (submodels.size() == 0) {
            std::vector< Model > results;
            return results;
        }
    }

    std::vector< Model > results;
    std::vector< std::vector< Model > > combinations;

    // Compute possible submodel combinations as coordinates in the model space defined earlier
    for (int k = 0; k < model_space.size(); ++k) {
        std::vector< Model > submodels = model_space[k];
        if (combinations.size() == 0) {
            for (auto iterator = submodels.begin(); iterator != submodels.end(); ++iterator) {
                std::vector< Model > combination;
                combination.push_back(* iterator);
                combinations.push_back(combination);
            }
        } else {
            std::vector< std::vector< Model > > new_combinations;
            for (auto iterator = combinations.begin(); iterator != combinations.end(); ++iterator) {
                std::vector< Model > combination = * iterator;
                for (auto iterator = submodels.begin(); iterator != submodels.end(); ++iterator) {
                    std::vector< Model > prefix(combination);
                    prefix.push_back(* iterator);
                    new_combinations.push_back(prefix);
                }
            }
            combinations = new_combinations;
        }
    }

    // Extract each submodel combination and map them to the feature_value that leads into each one. 
    for (auto iterator = combinations.begin(); iterator != combinations.end(); ++iterator) {
        std::vector< Model > combination = * iterator;
        std::map< int, Model > submodel_map;
        for (int k = 0; k < model_space.size(); ++k) {
            submodel_map[values[k]] = combination[k];
        }
        Model model(key.feature_index(), submodel_map);
        results.push_back(model);
    }
    return results;
}