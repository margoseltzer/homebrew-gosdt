#include "main.hpp"

int main(int argc, char *argv[]) {

	if (argc < 4 || argc > 5) {
		std::cout << "Usage: [path to binary] [path to feature set] [path to label set] [path to ouput]" << std::endl;
		return 0;
	}
	std::cout << "Optimal Sparse Decision Tree" << std::endl;
	std::cout << "Using feature set: " << argv[1] << std::endl;
	std::cout << "Using label set: " << argv[2] << std::endl;

	json dataset = {
		{"features", {
			 {"headers", json::array()},
			 {"data", json::array()}
		 }},
		{"labels", {
			 {"headers", json::array()},
			 {"data", json::array()}
		 }}
	};

	int line_index;
	io::LineReader features(argv[1]);
	line_index = 0;
	while (char * line = features.next_line()) {
		if (line_index == 0) {
			std::stringstream stream(line);
			std::string token;
			std::vector<std::string> tokens;
			while (stream.good()) {
				getline(stream, token, ',');
				tokens.push_back(token);
			}
			json row(tokens);
			dataset["features"]["headers"] = row;
		} else {
			json row = json::parse(std::string("[") + std::string(line) + std::string("]"));
			dataset["features"]["data"].push_back(row);
		}
		line_index += 1;
	}

	io::LineReader labels(argv[2]);
	line_index = 0;
	while (char * line = labels.next_line()) {
		if (line_index == 0) {
			std::stringstream stream(line);
			std::string token;
			std::vector<std::string> tokens;
			while (stream.good()) {
				getline(stream, token, ',');
				tokens.push_back(token);
			}
			json row(tokens);
			dataset["labels"]["headers"] = row;
		} else {
			json row = json::parse(std::string("[") + std::string(line) + std::string("]"));
			dataset["labels"]["data"].push_back(row);
		}
		line_index += 1;
	}

	GOSDT model;
	if (argc == 4) {
		model = GOSDT();
		std::cout << "Using default configuration: " << model.get_configuration() << std::endl;
	} else if (argc == 5) {
		std::ifstream in(argv[4]);
		std::string configuration((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
		model = GOSDT(configuration);
		std::cout << "Using custom configuration: " << model.get_configuration() << std::endl;
	}

	std::string result = model.fit(dataset.dump());

	std::cout << "Storing Models in: " << argv[3] << std::endl;
	std::ofstream out(argv[3]);
    out << result;
    out.close();

	return 0;
}
