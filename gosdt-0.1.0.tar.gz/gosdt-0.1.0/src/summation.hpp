#ifndef SUMMATION_H
#define SUMMATION_H

#include "task.hpp"

class Summation : public Task {
public:
    Summation(void);
    Summation(float const lowerbound, float const upperbound, float const support, Bitmask const & sensitivity);
private:
};

#endif
