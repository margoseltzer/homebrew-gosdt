#include "summand.hpp"

Summand::Summand(void) {}

Summand::Summand(int const feature_value) : _feature_value(feature_value) {}

int const Summand::feature_value(void) const {
    return this -> _feature_value;
}