#include "dataset.hpp"

Dataset::Dataset(void) {
    return;
}

Dataset::Dataset(std::istream & source) {
    json data;
    source >> data;
    initialize(data);
    return;
}


Dataset::Dataset(std::string const & source) {
    initialize(json::parse(source));
    return;
}

Dataset::Dataset(json const source) {
    initialize(source);
    return;
}

void Dataset::initialize(json const data) {
    json rows;
    int i, j;
    int size = 0;

    // Create a map of all binary labels (value defaulting to 0)
    std::map < boost::dynamic_bitset<>, int > labels;
    rows = data["labels"]["data"];
    for (json::iterator iterator = rows.begin(); iterator != rows.end(); ++iterator) {
        // Convert the label from a JSON array to a binary bitset
        json label = *iterator;
        boost::dynamic_bitset<> label_bitset;
        for (json::iterator sub_iterator = label.begin(); sub_iterator != label.end(); ++sub_iterator) {
            label_bitset.resize(label_bitset.size() + 1, (int)*sub_iterator);
        }
        // Force the initialization of a pair in the map
        labels[std::move(label_bitset)] = 0; 
        // Advance to the next sample label
        size += 1;
    }
    this -> _size = size;

    // Convert to a reverse index from binary label to position in the ordered map
    i = 0;
    for (std::map< boost::dynamic_bitset<>, int >::iterator iterator = labels.begin(); iterator != labels.end(); ++iterator) {
        iterator -> second = i;
        i++;
    }

    // Create a map of all binary features to their label distribution
    // label distribution buckets are ordered by their position in the previously constructed reverse index
    std::map < boost::dynamic_bitset<>, std::vector< int > > feature_map;
    rows = data["features"]["data"];
    i = 0;
    for (json::iterator iterator = rows.begin(); iterator != rows.end(); ++iterator) {
        // Convert the features from a JSON array to a binary bitset
        json sample = *iterator;
        boost::dynamic_bitset<> feature_bitset;
        for (json::iterator sub_iterator = sample.begin(); sub_iterator != sample.end(); ++sub_iterator) {
            feature_bitset.resize(feature_bitset.size() + 1, (int)*sub_iterator);
        }

        // Initialize the map and resize the value (of type vector) to the number of unique labels
        // This way the vector can hold the label distribution for this feature combination
        if (feature_map[feature_bitset].size() != labels.size() ) {
            feature_map[feature_bitset].resize(labels.size(), 0);
        }

        // Select the label associated with this instance of features (and convert from JSON array to binary bitset)
        json label = data["labels"]["data"][i];
        boost::dynamic_bitset<> label_bitset;
        for (json::iterator sub_iterator = label.begin(); sub_iterator != label.end(); ++sub_iterator) {
            label_bitset.resize(label_bitset.size() + 1, (int)*sub_iterator);
        }

        // Find the position of the associated label using the previously constructed reverse index
        const int label_index = labels[label_bitset];

        // Increase the frequency of this label in the distribution associated with this feature conbination
        feature_map[std::move(feature_bitset)][label_index] += 1;
        // Advance to the next sample feature
        ++i;
    }

    // At this point we have two data structures:
    //  labels :: map < dynamic_bitset, int > which is a reverse index of all known labels
    //  feature_map :: map < dynamic_bitset, vector < int > > which is an association from all known feature combinations
    //      to a vector of label distributions (frequency) for that particular feature combination
    //      where the frequency in the distribution is ordered in the same order as the labels' reverse index

    // As this algorithm is offline (for now), we can convert both maps into vectors for faster iteration in
    // without worrying about new samples affecting the reverse index or distributions

    // Convert the labels map into a vector of tuples
    for (auto iterator = labels.begin(); iterator != labels.end(); ++iterator) {
        this -> labels.push_back(std::tuple< Bitmask, int >(Bitmask(iterator -> first), iterator -> second));
    }

    // Convert the feature_map map into a vector of tuples
    i = 0;
    for (auto iterator = feature_map.begin(); iterator != feature_map.end(); ++iterator) {
        this -> rows.push_back(std::tuple< Bitmask, std::vector< int > >(Bitmask(iterator -> first), iterator -> second));
        ++i;
    }

    std::vector< boost::dynamic_bitset<> > columns;
    // Build vector of columns based on 
    for (j = 0; j < feature_map.begin() -> first.size(); ++j) {
        boost::dynamic_bitset<> column;
        column.resize(feature_map.size());
        columns.push_back(column);
    }

    i = 0;
    for (auto iterator = this -> rows.begin(); iterator != this -> rows.end(); ++iterator) {
        Bitmask row = std::get<0>(*iterator);
        for (j = 0; j < row.size(); ++j) {
            columns[j][i] = row[j];
        }
        ++i;
    }
    for (auto iterator = columns.begin(); iterator != columns.end(); ++iterator) {
        this -> columns.push_back(Bitmask(*iterator));
    }

    this -> shape = std::tuple< int, int, int >(this -> rows.size(), this -> columns.size(), this -> labels.size());

    if (rows.size() < 1 || columns.size() < 1 || labels.size() < 1) { throw "Dataset must not be empty."; }

    initialize_kernel();
    return;
}

void Dataset::initialize_kernel(void) {
    try {
        std::vector< cl::Platform > platforms;
        cl::Platform::get(&platforms);
        if (platforms.size() == 0) {
            std::cout << "No OpenCL platforms found. Please ensure OpenCL is installed." << std::endl;
        }
        std::cout << "List of OpenCL platforms:" << std::endl;
        for (int i = 0; i < platforms.size(); ++i) {
            std::cout << "    " << platforms[i].getInfo<CL_PLATFORM_NAME>() << std::endl;
        }
        cl::Platform platform = platforms[0];
        std::cout << "Using platform: " << platform.getInfo<CL_PLATFORM_NAME>() << std::endl;

        std::vector< cl::Device > devices;
        platform.getDevices(CL_DEVICE_TYPE_ALL, &devices);
        if (devices.size() == 0) {
            std::cout << " No devices found. Check OpenCL installation!" << std::endl;
        }
        std::cout << "List of OpenCL devices:" << std::endl;
        for (int i = 0; i < devices.size(); ++i) {
            std::cout << "    " << devices[i].getInfo<CL_DEVICE_NAME>() << std::endl;
        }
        cl::Device device = devices[0];
        std::cout << "Using device: " << device.getInfo<CL_DEVICE_NAME>() << std::endl;

        cl::Context context({device});

        std::string kernel_source =
            "   void kernel simple_add(global const int * A, global const int * B, global int * C) {   "
            "       C[get_global_id(0)] = A[get_global_id(0)] + B[get_global_id(0)];   "
            "   }  ";

        cl::Program::Sources sources;
        sources.push_back({kernel_source.c_str(), kernel_source.length()});

        cl::Program program(context,sources);
        if (program.build({device}) != CL_SUCCESS) {
            std::cout << "OpenCL Build Error: " << program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(device) << std::endl;
        }
        cl::Buffer buffer_A(context, CL_MEM_READ_WRITE, sizeof(int) * 10);
        cl::Buffer buffer_B(context, CL_MEM_READ_WRITE, sizeof(int) * 10);
        cl::Buffer buffer_C(context, CL_MEM_READ_WRITE, sizeof(int) * 10);
        int A[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        int B[] = {0, 1, 2, 0, 1, 2, 0, 1, 2, 0};

        cl::CommandQueue queue(context, device);
        queue.enqueueWriteBuffer(buffer_A, CL_TRUE, 0, sizeof(int) * 10, A);
        queue.enqueueWriteBuffer(buffer_B, CL_TRUE, 0, sizeof(int) * 10, B);

        int thread_count = 10;

        cl::Kernel simple_add(program, "simple_add");
        simple_add.setArg(0, buffer_A);
        simple_add.setArg(1, buffer_B);
        simple_add.setArg(2, buffer_C);
        queue.enqueueNDRangeKernel(simple_add, cl::NullRange, cl::NDRange(10), cl::NullRange);

        // cl::KernelFunctor simple_add(cl::Kernel(program, "simple_add"), queue, cl::NullRange, cl::NDRange(thread_count), cl::NullRange);
        // simple_add(buffer_A, buffer_B, buffer_C);

        int C[10];
        //read result C from the device to array C
        queue.enqueueReadBuffer(buffer_C, CL_TRUE, 0, sizeof(int) * 10, C);

        std::cout << " result:";
        for (int i = 0; i < 10; i++) {
            std::cout << C[i] << " ";
        }
        std::cout << std::endl;
    } catch( cl::Error error ) {
        std::cout << "OpenCLError" << int(error.err()) << ": " << error.what() << std:: endl;
    }

}

Dataset::~Dataset(void) {
    return;
}

std::tuple< float, float, float > Dataset::impurity(void) const {
    return _impurity(Bitmask::ones(height()));
}

std::tuple< float, float, float > Dataset::impurity(Bitmask const & indicator) const {
    return _impurity(indicator);
}

std::tuple< float, float, float > Dataset::_impurity(Bitmask const & indicator) const {
    if (indicator.size() != height()) { throw "Indicator size does not match dataset height."; }

    float minimum_impurity = 0.0;
    std::vector< int > accumulator;
    accumulator.resize(depth(), 0);
    for (int i = 0; i < height(); ++i) {
        if (indicator[i] != 1) { continue; }

        std::vector< int > element = std::get<1>(this -> rows[i]);
        int subtotal = 0; // Total label frequency for this feature set
        int maximum = 0; // Maximum label frequency for this feature set
        for (int j = 0; j < element.size(); ++j) {
            maximum = element[j] > maximum ? element[j] : maximum;
            subtotal += element[j];
            accumulator[j] += (float) element[j];
        }
        minimum_impurity += subtotal - maximum;
    }
    int maximum = 0;
    int total = 0;
    for (std::vector< int >::iterator iterator = accumulator.begin(); iterator != accumulator.end(); ++iterator) {
        int frequency = *iterator;
        maximum = frequency > maximum ? frequency : maximum;
        total += frequency;
    }
    float maximum_impurity = total - maximum;
    std::tuple< float, float, float > impurity(minimum_impurity, maximum_impurity, total);
    return impurity;
}


std::map< int, Bitmask > Dataset::partition(int const feature_index) const {
    return _partition(Bitmask::ones(height()), feature_index);
}

std::map< int, Bitmask > Dataset::partition(Bitmask const & indicator, int const feature_index) const {
    return _partition(indicator, feature_index);
}

std::map< int, Bitmask > Dataset::_partition(Bitmask const & indicator, const int feature_index) const {
    if (indicator.size() != height()) { throw "Indicator size does not match dataset height."; }
    Bitmask feature = this -> columns[feature_index];
    std::map< int, Bitmask > partitions;
    partitions[0] = (indicator & ~feature);
    partitions[1] = (indicator & feature);
    return partitions;
}

std::map< Bitmask, int > Dataset::distribution(void) const {
    return distribution(Bitmask::ones(height()));
}

std::map< Bitmask, int > Dataset::distribution(Bitmask const & indicator) const {
    if (indicator.size() != height()) { throw "Indicator size does not match dataset height."; }

    std::vector< int > distribution;
    distribution.resize(depth(), 0);
    for (int i = 0; i < height(); ++i) {
        if (indicator[i] != 1) { continue; }
        std::vector< int > element = std::get<1>(this -> rows[i]);
        for (int k = 0; k < depth(); ++k) {
            distribution[k] += element[k];
        }
    }
    std::map< Bitmask, int > distribution_map;
    for (int k = 0; k < depth(); ++k) {
        Bitmask const & label = std::get<0>((this -> labels)[k]);
        distribution_map[label] = distribution[k];
    }
    return distribution_map;
}

int const Dataset::height(void) const {
    return std::get<0>(this -> shape);
}

int const Dataset::width(void) const {
    return std::get<1>(this -> shape);
}

int const Dataset::depth(void) const {
    return std::get<2>(this -> shape);
}

int const Dataset::size(void) const {
    return this -> _size;
}
