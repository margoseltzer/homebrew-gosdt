#ifndef TASK_H
#define TASK_H

#include <vector>
#include <tuple>
#include "key.hpp"

class Task {
public:
    Task(void);
    Task(float const lowerbound, float const upperbound, float const support, Bitmask const & sensitivity);

    float const support(void) const;
    float const lowerbound(void) const;
    float const upperbound(void) const;
    float const potential(void) const;
    float const uncertainty(void) const;
    float const objective(void) const;
    Bitmask const & sensitivity(void) const;

    void inform(float const lowerbound, float const upperbound);

    bool const explored(void) const;
    bool const delegated(void) const;
    bool const cancelled(void) const;
    bool const resolved(void) const;

    void explore(void);
    void delegate(void);
    void cancel(void);
    void resolve(void);

    std::vector< std::tuple< int, int, float > > similarity_index;

private:
    float _support;
    float _lowerbound;
    float _upperbound;
    float _potential;

    Bitmask _sensitivity;

    bool _explored = false;
    bool _delegated = false;
    bool _resolved = false;
    bool _cancelled = false;
};

#endif