#include "../src/alternative.hpp"

int test_alternative(void) {
    int failures = 0;

    Alternative alternative;

    return failures;

}