#include "../src/graph.hpp"
#include <vector>

int test_graph(void) {
    int failures = 0;
    bool throws;
    return failures;

}