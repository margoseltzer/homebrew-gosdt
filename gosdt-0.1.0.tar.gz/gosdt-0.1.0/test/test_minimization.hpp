#include "../src/minimization.hpp"

int test_minimization(void) {
    int failures = 0;
    bool throws;
    Minimization task(0.21, 0.32, 0.5, 0.76, Bitmask::ones(5));

    failures += expect(0.21, task.lowerbound(), "Test Minimization::lowerbound fails equality with constructor argument.");
    failures += expect(0.32, task.upperbound(), "Test Minimization::upperbound fails equality with constructor argument.");
    failures += expect(0.5, task.support(), "Test Minimization::support fails equality with constructor argument.");
    failures += expect(0.11, task.uncertainty(), "Test Minimization::uncertainty fails equality with constructor argument.");
    failures += expect(0.11, task.potential(), "Test Minimization::potential fails equality with constructor argument.");
    failures += expect(0.76, task.base_objective(), "Test Minimization::potential fails equality with constructor argument.");

    throws = false;
    try { task.objective(); } catch (const char * e) { throws = true; }
    failures += expect(true, throws, "Test Minimization::objective doesn't throw on invalid objective query.");

    task.inform(0.22, 0.31);
    failures += expect(0.22, task.lowerbound(), "Test Minimization::inform fails to update lowerbound.");
    failures += expect(0.31, task.upperbound(), "Test Minimization::inform fails to update upperbound.");
    failures += expect(0.09, task.uncertainty(), "Test Minimization::uncertainty fails to reflect updated state.");
    failures += expect(0.11, task.potential(), "Test Minimization::potential fails remain constant.");

    throws = false;
    try { task.inform(0.88, 0.31); } catch (const char * e) { throws = true; }
    failures += expect(true, throws, "Test Minimization::inform doesn't throw on invalid update.");

    return failures;

}