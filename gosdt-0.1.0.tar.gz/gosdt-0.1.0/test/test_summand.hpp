#include "../src/summand.hpp"

int test_summand(void) {
    int failures = 0;

    int const feature_value = 1;
    Summand summand(feature_value);

    failures += expect(feature_value, summand.feature_value(), "Test Summand::feature_value fails equality with constructor argument.");

    return failures;

}