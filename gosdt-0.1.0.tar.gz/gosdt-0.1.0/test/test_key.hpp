#include "../src/key.hpp"

int test_key(void) {
    int failures = 0;

    // // Test Key::Key(indicator);
    // // Test Key::Key(indicator, feature_index);
    boost::dynamic_bitset<> indicator_value(4);
    indicator_value[0] = 0;
    indicator_value[1] = 1;
    indicator_value[2] = 0;
    indicator_value[3] = 1;
    Bitmask indicator = Bitmask(indicator_value);
    int feature_index = 2;

    Key minimization_key(indicator);
    Key summation_key(indicator, feature_index);

    // Test Key::indicator()
    failures += expect(true, indicator == minimization_key.indicator(), "Test Key::indicator reference Failed.");

    // Test Key::indicator shares reference to the same dynamic bitset
    // failures += expect(true, std::addressof(minimization_key.indicator().value()) == std::addressof(summation_key.indicator().value()), "Test Key Indicator Sharing Failed.");

    // Test Key::feature_index()
    failures += expect(-1, minimization_key.feature_index(), "Test Minimization Key::feature_index Failed.");
    failures += expect(2, summation_key.feature_index(), "Test Summation Key::feature_index Failed.");

    // Test Key::==(other)
    failures += expect(false, summation_key == minimization_key, "Test Key::== Operator.");
    failures += expect(true, summation_key == summation_key, "Test Key::== Operator.");

    failures += expect(false, minimization_key.indicator() < summation_key.indicator(), "Sanity");
    failures += expect(true, minimization_key.feature_index() < summation_key.feature_index(), "Sanity");

    failures += expect(true, minimization_key < summation_key, "Test Key::< Operator.");
    failures += expect(true, minimization_key <= summation_key, "Test Key::<= Operator.");
    failures += expect(false, minimization_key > summation_key, "Test Key::> Operator.");
    failures += expect(false, minimization_key >= summation_key, "Test Key::>= Operator.");

    return failures;

}