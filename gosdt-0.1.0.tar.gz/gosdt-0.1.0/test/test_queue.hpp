#include "../src/queue.hpp"

int test_queue(void) {
    int failures = 0;
    return failures;

}