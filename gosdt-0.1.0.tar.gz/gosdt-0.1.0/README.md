# GOSDT Documentation
Implementation of [Generalized Optimal Sparse Decision Tree](<URL to publication>).

# Table of Content
[**Usage**](/doc/usage.md)
   
uide for users.

Describes how to use the library as a stand-alone program or part of a larger application.

---

[**Development**](/doc/development.md)
Guide for developers.

Describes the project structure and tooling available.
 
---

[**Performance Analysis**](doc/performance.md)

Displays performance analysis of implementation.

---

[**Dependencies**](doc/dependencies.md)

List of external dependencies

---

[**License**](doc/license.md)

Licensing information
