[Back](/README.md)

# Performance Analysis
Displays performance analysis of implementation.


Below are references to notebooks containing experiments performed on the implementation
  - Accuracy - `jupyter notebook notebook/accuracy.ipynb`
  - Scalability - `jupyter notebook notebook/scalability.ipynb`
  - Memory Profiling - `jupyter notebook notebook/memory.ipynb`