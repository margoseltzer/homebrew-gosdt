[Back](/README.md)

# Development
For developers.


Describes the project structure and tooling available.

# Repository Structure
 - **notebooks** - interactive notebooks for examples and visualizations
 - **experiments** - configurations, datasets, and models to run experiments
 - **doc** - documentation
 - **python** - code relating to the Python implementation and wrappers around C++ implementation
 - **auto** - automations for checking and installing project dependencies
 - **dist** - compiled binaries for distribution
 - **build** - compiled binary objects and other build artifacts
 - **lib** - headers for external libraries
 - **log** - log files
 - **src** - source files
 - **test** - test files

# Installing Dependencies
Refer to [**Dependency Installation**](/doc/dependencies.md##Installation)

# Build Process
 - **Check for Missing Dependencies** 
   ```
   ./autobuild --configure --enable-tests
   ```
 - **Build and Run Test Suite**
   ```
   ./autobuild --test
   ```
 - **Build and Install Program**
   ```
   ./autobuild --install --enable-tests
   ```
 - **Run the Program** 
   ```
   gosdt \
   experiments/datasets/compas_small/features.csv \
   experiments/datasets/compas_small/labels.csv \
   experiments/models/compas_small.json \
   experiments/configurations/compas_small.json
   ```
 - **Build and Install the Python Extension**
   ```
   ./autobuild --install-python
   ```

 For a full list of build options, run `./autobuild --help`

# Tasks
**Documentation**:
 - Combine Python and C++ Documentation

**Release & Distribution**:
 - Ask Margo about: Where to upload the distribution? Distribution Policy? Urgency of Brew, APT, PIP release?
 - Repository Consolidation (Merge the Python and C++ implementations and consolidate our rendering/visualization code)
 - End-to-End Test (Add a few end-to-end test cases based on small datasets)

**Optimization**:
 - Cart Upperbound Sampling (Switch the upperbound sampling technique from optimal stump to a greedy CART tree)
 - Try Merging vertices (Single "Task" intead of alternating Min and Sum)
 - Dataset Segment Tree Reduction (Replace sequential dataset summation with segment tree summation)

**Scheduling**:
 - Calculate the expected resulting tree interval with the complement problem, then schedule by lowerbound of that parent
 - Non-delegation on most promising call for more locality?
 - Segment tasks by locality biases to reduce contention / cache-bouncing
 - Store confidence levels to improve scheduling (Scheduling policy based on expected risk of each alternative split)
 - Probabilistic scheduling (Relax scheduling priority using a probabilistic model)
 - Learned scheduling policy (Collect runtime data and learn a better scheduling policy)
 - Garbage Collection (Implement a garbage collector that detects probably unreachable subsets at runtime)

**Parallelization & Hardware Acceleration**:
 - GPU Reduction (Add option for dataset summation using GPU kernel)
 - Granularity Control (Minimum size of asynchronous delegation)
 - Loop-parallel optimization (Try adding loop-parallelism from TBB library)

**Visualization**:
 - (Python) rendering tree models (Assigned to Sophie)

**Experimentation (results we're interested in)**:
 - Scalability analysis (Requires Ubuntu build)
 - Run on full (not greedy-mined) COMPAS dataset with age, prior, race, and gender and examine the resulting model (Requires tuning of regularizer)

**Additional Features (Optional)**:
 - Model Prediciton for C++ class (Add inference methods for the C++ class so it can be incorporated into other C++ projects)