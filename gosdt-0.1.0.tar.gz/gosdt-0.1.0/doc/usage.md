[Back](/README.md)

# Usage
For users.

Describes how to use the library as a stand-alone program or part of a larger application.

# Installing Dependencies
Refer to [**Dependency Installation**](/doc/dependencies.md##Installation)

# As a Stand-Alone Command Line Program
## Installation
```
./autobuild --install
```

## Executing the Program
```
gosdt \
experiments/datasets/compas_small/features.csv \
experiments/datasets/compas_small/labels.csv \
experiments/models/compas_small.json \
experiments/configurations/compas_small.json
```

# As a Python Library with C++ Extensions
## Build and Installation
```
./autobuild --install-python
```
_If you have multiple Python installations, please make sure to build and install using the same Python installation as the one intended for interacting with this library._

---
## Importing Extension with Python Wrapper
```python
from python.model.optimal_sparse_decision_forest import OptimalSparseDecisionForest
```
Refer the the example.ipynb notebook for usage by running `jupyter notebook notebook/example.ipynb`

## Importing the C++ Extension Alone
```python
from osdt import fit
```
---